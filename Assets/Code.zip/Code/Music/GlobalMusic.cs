﻿using UnityEngine;

namespace SurgeEngine.Code.Music
{
    public class GlobalMusic : MonoBehaviour
    {
        
    }
}