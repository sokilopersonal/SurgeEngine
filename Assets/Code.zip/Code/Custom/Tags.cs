﻿namespace SurgeEngine.Code.Custom
{
    public static class Tags
    {
        public const string AllowBoost = "AllowBoost";
    }
}