namespace SurgeEngine.Code.Actor.CameraSystem.Modifiers
{
    public class BoostDistanceCameraModifier : BoostBaseCameraModifier
    {
    }
}