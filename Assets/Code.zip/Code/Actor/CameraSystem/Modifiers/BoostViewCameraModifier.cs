namespace SurgeEngine.Code.Actor.CameraSystem.Modifiers
{
    public class BoostViewCameraModifier : BoostBaseCameraModifier
    {
    }
}