namespace SurgeEngine.Code.Actor.CameraSystem.Modifiers
{
    public interface ICameraFloatModifier
    {
        float Value { get; set; }
    }
}