﻿using SurgeEngine.Code.Actor.CameraSystem.Pawns.Data;
using SurgeEngine.Code.Actor.System;
using UnityEngine;

namespace SurgeEngine.Code.Actor.CameraSystem.Pawns
{
    public class VerticalCameraPan : NewModernState
    {
        private VerticalPanData _vData;
        private LastCameraData _lastData;
        
        public VerticalCameraPan(ActorBase owner) : base(owner)
        {
            
        }

        public override void OnEnter()
        {
            _stateMachine.ResetBlendFactor();
            _lastData = _stateMachine.RememberRelativeLastData();
        }

        public override void OnExit()
        {
            base.OnExit();
            
            _stateMachine.SetDirection(_vData.RestoreDirection());
        }

        public override void OnTick(float dt)
        {
            _vData = (VerticalPanData)_data;
            _stateMachine.currentData = _vData;
            _stateMachine.distance = Mathf.Lerp(_lastData.distance, _vData.distance, _stateMachine.interpolatedBlendFactor);
            _stateMachine.yOffset = Mathf.Lerp(_lastData.yOffset, _vData.yOffset, _stateMachine.interpolatedBlendFactor);
            
            _stateMachine.SetDirection(_vData.forward);
            
            _stateMachine.camera.fieldOfView = Mathf.Lerp(_lastData.fov, _vData.fov, _stateMachine.interpolatedBlendFactor);
            
            base.OnTick(dt);
        }

        protected override void SetPosition(Vector3 targetPosition)
        {
            Vector3 center = _stateMachine.actorPosition;
            Vector3 diff = targetPosition - center;
            _stateMachine.position = Vector3.Slerp(_lastData.position, diff, _stateMachine.interpolatedBlendFactor);
            _stateMachine.position += center;
        }
        
        protected override void SetRotation(Vector3 actorPosition)
        {
            Vector3 look = 
                actorPosition
                + _stateMachine.transform.TransformDirection(_stateMachine.lookOffset)
                - _stateMachine.position;
            
            if (look != Vector3.zero)
            {
                Quaternion rot = Quaternion.LookRotation(look);
            
                _stateMachine.rotation = Quaternion.Lerp(_lastData.rotation, rot, _stateMachine.interpolatedBlendFactor);
            }
        }

        protected override void LookAxis()
        {
            
        }

        protected override void AutoLookDirection()
        {
            _stateMachine.xAutoLook = 0;
            _stateMachine.yAutoLook = 0;
        }
    }
}