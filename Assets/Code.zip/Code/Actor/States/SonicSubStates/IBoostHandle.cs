﻿namespace SurgeEngine.Code.Actor.States.SonicSubStates
{
    public interface IBoostHandler
    {
        void BoostHandle();
    }
}