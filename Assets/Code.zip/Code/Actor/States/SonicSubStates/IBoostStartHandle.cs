﻿namespace SurgeEngine.Code.Actor.States.SonicSubStates
{
    public interface IBoostStartHandle
    {   
        void StartBoostHandle();
    }
}