using SurgeEngine.Code.Actor.States.BaseStates;
using SurgeEngine.Code.Actor.System;

namespace SurgeEngine.Code.Actor.States
{
    public class FStateDead : FActorState
    {
        public FStateDead(ActorBase owner) : base(owner)
        {
            
        }
    }
}