using DG.Tweening;
using UnityEngine;

namespace SurgeEngine.Code.UI.Menus.OptionTabs
{
    public class GameTab : Tab
    {
        protected override void InsertIntroAnimations()
        {
            base.InsertIntroAnimations();
        }

        protected override void InsertOutroAnimations()
        {
            base.InsertOutroAnimations();
        }
    }
}