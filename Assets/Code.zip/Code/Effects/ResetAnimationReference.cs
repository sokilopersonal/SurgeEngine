﻿using UnityEngine;

namespace SurgeEngine.Code.ActorEffects
{
    public class ResetAnimationReference : MonoBehaviour
    {
        public void ResetAction()
        {
        }
    }
}