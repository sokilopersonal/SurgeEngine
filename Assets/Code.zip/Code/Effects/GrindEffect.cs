﻿namespace SurgeEngine.Code.ActorEffects
{
    public class GrindEffect : Effect
    {
        
    }
}