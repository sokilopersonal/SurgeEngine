using SurgeEngine.Code.CommonObjects;
using UnityEngine;
using Zenject;

namespace SurgeEngine.Code.DI
{
    public class ActorStartInstaller : MonoInstaller
    {

        public override void InstallBindings()
        {
            
        }
    }
}