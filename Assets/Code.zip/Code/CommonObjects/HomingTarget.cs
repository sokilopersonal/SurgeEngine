﻿using UnityEngine;
using UnityEngine.Events;

namespace SurgeEngine.Code.CommonObjects
{
    public class HomingTarget : MonoBehaviour
    {
        public UnityEvent OnTargetReached;
    }
}